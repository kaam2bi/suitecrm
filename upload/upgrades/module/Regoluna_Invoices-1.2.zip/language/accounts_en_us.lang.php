<?php

$mod_strings [ "LBL_FACTURAS" ] = "Invoices" ;